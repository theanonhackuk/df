<?php
//83886080-100663295
$ranges=Array(
);
?>