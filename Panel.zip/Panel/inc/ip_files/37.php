<?php
//620756992-637534207
$ranges=Array(
);
?>